check out my youtube channel: https://www.youtube.com/channel/UChkBRYjU0nTzVjUx0_wUrLg
also check out my reddit: https://www.reddit.com/user/SYSTEMATICA_32

and if you haven't already, install python here: https://www.python.org/downloads/

thanks for downloading story generator. i also don't expect you to donate, but please do if you want to.
everything in this is created by me.