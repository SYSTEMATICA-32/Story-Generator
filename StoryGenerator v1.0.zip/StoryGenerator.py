import time
print("Story Generator version: 1.0")
print("Story Generator by SYSTEMATICA_32")
time.sleep(3.5)
name=input("[Story Generator]: Enter your name: ")


if name == "SYSTEMATICA_32":
    print("[Story Generator]: Greetings, creator.")
    

else:
    print("Hello,", name + "! Welcome to Story Generator.")

time.sleep(1.5)
friend1=input("[Story Generator]: Name a friend/family member. ")
print("[Story Generator]: Your friend/family member's name is: ", friend1 + ".")
time.sleep(1.5)
friend2=input("[Story Generator]: Name another friend/family member. ")
print("[Story Generator]: Your other friend/family member's name is: ", friend2 + ".")
time.sleep(1.5)
thing=input("[Story Generator]: What's your favourite object?(put it in singular form, please.) ")
print("[Story Generator]: Your favourite object is: ", thing + ".")
time.sleep(1.5)
thing2=input("[Story Generator]: What's your favourite thing to do? (Please put an ing after the verb. Example: programming.) ")

if thing2 == "programming":
    print("same lmao")

else:
    print("Your favourite thing to do is: ", thing2 + ".")

time.sleep(1.5)
food=input("[Story Generator]: What's your favourite food? ")
print("[Story Generator]: Okay. So, your favourite food is: ", food + ".")
time.sleep(1.5)
number=input("[Story Generator]: What's your favourite number?")
print("[Story Generator]: Your favourite number is ", number + ".")
time.sleep(1.5)
print("[Story Generator]: Your story is being written. Hang on...")
time.sleep(5)
print("[Story Generator]: You and your two friends/family members,", friend1 + " and", friend2 + " are inside eating", food + ". What a peaceful day. You look outside to find ", food + "(s/es) growing on a tree. Then a bird swoops down and steals a/an ", food + " from the tree. There is a dog in an alleyway barking loudly. You and your friends throw ", food + "(s/es) at the dog. The dog knocks you unconscious and steals all your", food + ". Your friends drag your body out of the alley. You wake up confused and hungry. You begin to realize", friend1 + " and ", friend2 + " left you behind. You have no choice but to carry on and go back home. You come back to them throwing a party, the room a total mess, streamers everywhere and", thing + "(s/es) on the couch. ", friend2 + " drops on the floor and passes out.", friend1 + " looks shocked. They explain what happened. You dial 911. 'Hello. This is ", name + ", my friend/family member passed out.' 'Oh dear,' the employee replies. 'We'll be right there.' They hang up.", friend2 + " looks very ill. You have nothing better to do at the moment, so you start ", thing2 + ". ", friend1 + " also likes ", thing2 + ", so they join you. Afterwards, you go for a walk around the neighbourhood with ", friend1 + ", while the hospital takes care of ", friend2 + ". You find ", number + " ", thing + "(s/es) on the ground.")